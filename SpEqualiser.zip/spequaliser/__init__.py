"""
Real-Time Audio Equalizer & Spectrum Analyzer
A Digital Signal Processing Package
"""

__version__ = "1.0.0"
