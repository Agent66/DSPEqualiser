# Real-Time Audio Equalizer & Spectrum Analyzer
### A Digital Signal Processing (DSP) Project in Python

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![DSP Suite](https://img.shields.io/badge/DSP-Real--Time-00f2fe.svg)](https://github.com/)
[![Tests](https://img.shields.io/badge/Tests-100%25%20Passing-emerald.svg)](tests/)

An end-to-end, real-time audio processing system implementing core Digital Signal Processing (DSP) concepts: **sampling & digitization**, **windowing (Hann/Hamming)**, **Fast Fourier Transform (FFT)**, **digital filter design (Low-pass, High-pass, Band-pass, Notch)**, **multi-band graphic equalizer**, **oscilloscope waveform visualization**, and advanced DSP extensions (**pitch detection** & **spectral subtraction noise reduction**).

---

## Key Features & DSP Concepts

| Concept (from Slides) | Implementation Details |
|---|---|
| **Sampling & Real-Time I/O** | 44.1 kHz sampling rate, 2048-sample block processing (~46 ms latency), full-duplex stream via `sounddevice` |
| **Windowing & Leakage** | Hann, Hamming, and Rectangular windowing functions; suppresses spectral sidelobe leakage by >50 dB |
| **FFT Spectrum Analysis** | Single-sided $N$-point FFT (`rfft`), calibrated dB magnitude scale, parabolic sub-bin peak frequency interpolation (<0.2% error) |
| **Digital Filters** | 2nd & 4th-order Butterworth Low-Pass, High-Pass, Band-Pass, and IIR Notch (60 Hz mains hum rejection) using Second-Order Sections (SOS) |
| **8-Band Equalizer** | 63 Hz, 160 Hz, 400 Hz, 1 kHz, 2.5 kHz, 6 kHz, 12 kHz, 16 kHz peaking and shelving biquads with zero-transient state preservation (`zi`) |
| **Live Visualizer** | Embedded Matplotlib UI rendering simultaneous time-domain oscilloscope waveform and frequency spectrum analyzer at 30+ FPS |
| **Pitch Detection** | Normalized Autocorrelation Function (NACF) extracting fundamental frequency $F_0$ (50–2000 Hz) with musical note and cents deviation |
| **Noise Reduction** | Spectral Subtraction algorithm with background noise profiling, over-subtraction factor $\alpha$, and spectral floor $\beta$ |

---

## Project Structure

```
SpEqualiser/
├── requirements.txt            # Package dependencies
├── main.py                     # GUI Application Launcher
├── verify_dsp.py               # Complete mathematical validation suite for all DSP objectives
├── spequaliser/
│   ├── __init__.py
│   ├── dsp.py                  # Core DSP: Windowing, FFT, Biquad IIR filters, SOS state continuity, pitch & denoiser
│   ├── audio_engine.py         # Real-time audio stream worker (sounddevice, ring buffers, routing)
│   ├── generators.py           # Signal synthesizers (Sine, Chirp sweep, Pink/White noise, Chord) & WAV player
│   └── gui.py                  # Dark-themed GUI with dual live visualization & interactive console
└── tests/
    └── test_dsp.py             # Automated unit tests
```

---

## Installation & Setup

1. **Clone or navigate to the repository directory**:
   ```bash
   cd c:\Users\noneo\SpEqualiser
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

---

## How to Run

### 1. Launch the Real-Time GUI Application

```bash
python main.py
```

- **Audio Sources**:
  - **Demo Music**: Built-in multi-track electronic synth groove (bassline + chords + hi-hat) for instant EQ testing.
  - **Test Gen**: Pure Sine tone (adjustable Hz), Logarithmic Frequency Sweep (20 Hz to 20 kHz), White Noise, Pink Noise, and Harmonic A-major Chord.
  - **WAV File**: Open your own music or audio recordings.
  - **Live Mic**: Direct input from your computer microphone.
- **Equalizer Controls**:
  - Adjust vertical faders (-12 dB to +12 dB) across 8 musical frequency bands.
  - Choose presets: *Flat*, *Bass Boost*, *Vocal Booster*, *Treble Boost*, *Acoustic*, *Electronic / EDM*, *Rock*, *Speech Clarifier*.
- **Digital Filter Controls**:
  - Select *Low-Pass*, *High-Pass*, *Band-Pass*, or *Notch*.
  - Sweep the cutoff frequency slider and watch the output spectrum and EQ target curve adapt live!
- **DSP Extensions**:
  - Watch the live **Pitch Detector** display the detected note (e.g., `A4 (440.1 Hz)`) and tuning deviation in cents.
  - Switch FFT Windowing from *Hann* to *Rectangular* to see spectral leakage.
  - Enable **Denoiser** and click *Calibrate Profile* to suppress stationary background noise.

---

### 2. Run the Automated Mathematical DSP Verification Suite

```bash
python verify_dsp.py
```

This validates all project requirements against theoretical DSP criteria:
- **FFT Accuracy**: Verifies dominant tone peak identification with sub-bin precision (<0.5% error).
- **Window Leakage**: Confirms Hann window delivers >50 dB deeper sidelobe rejection than rectangular windowing.
- **Filter Responses**: Validates passband flat response and stopband rejection (>40 dB for LP/HP, >80 dB for 60 Hz Notch).
- **State Continuity**: Confirms block-by-block filtering has zero boundary error ($0.00\times 10^0$ error).
- **Pitch Detection**: Tests 7 musical notes across octaves A2 to A5.
- **Noise Reduction**: Validates >30 dB spectral noise suppression.

### 3. Run Unit Tests

```bash
python -m unittest discover -s tests -p "test_*.py"
```
