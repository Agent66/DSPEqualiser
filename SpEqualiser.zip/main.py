"""
Main Entry Point: Real-Time Audio Equalizer & Spectrum Analyzer.
"""

import sys
import tkinter as tk
from spequaliser.gui import EqualizerApp


def main():
    root = tk.Tk()
    app = EqualizerApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()


if __name__ == "__main__":
    main()
